int main(void)
{
  j = k + multi_fun(l, m) / n;
}

int multi_fun(l, m)
{
  temp = l * m;
  return temp;
}
