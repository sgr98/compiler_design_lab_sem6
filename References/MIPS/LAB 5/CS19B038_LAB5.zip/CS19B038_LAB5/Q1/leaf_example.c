int leaf_example (int g, int h, int i, int j)
{
  int f;
  f = (g + h) – (i + j);
  return f;
}
