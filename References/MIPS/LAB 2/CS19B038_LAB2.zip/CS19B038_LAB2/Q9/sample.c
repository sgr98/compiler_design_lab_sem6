#include<stdio.h>

void main() {
    int a;
    a = 9;
    a = a + 5;
    printf("d", a);
}